/**
 * 
 */
/**
 * 
 */
module JuegoPlataforma {
	requires java.desktop;
	requires java.xml;
}