/**
 * 
 */
/**
 * 
 */
module Biblioteca {
	requires jdk.jfr;
	requires java.xml.bind;
	requires java.desktop;
}